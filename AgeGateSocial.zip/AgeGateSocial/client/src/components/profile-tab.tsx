import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin, Shield, Clock, User } from "lucide-react";

interface UserData {
  id: number;
  fullName: string;
  age: number;
  ageCategory: string;
  tokenId: string;
  tokenExpiry: string;
}

interface ProfileTabProps {
  userData: UserData;
  onLogout: () => void;
}

export default function ProfileTab({ userData, onLogout }: ProfileTabProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getAgeGroupColor = (category: string) => {
    switch (category) {
      case '18+': return 'bg-red-100 text-red-800';
      case '16+': return 'bg-yellow-100 text-yellow-800';
      case '13+': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Profile Header */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-0">
          <div className="relative">
            {/* Cover Photo */}
            <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-t-lg"></div>
            
            {/* Profile Info */}
            <div className="relative px-6 pb-6">
              <div className="flex flex-col md:flex-row md:items-end md:justify-between">
                <div className="flex items-end space-x-4">
                  {/* Avatar */}
                  <div className="relative -mt-12">
                    <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg border-4 border-white">
                      <User className="w-12 h-12 text-gray-400" />
                    </div>
                  </div>
                  
                  {/* Name and Age */}
                  <div className="pb-2">
                    <h1 className="text-2xl font-bold text-gray-900">{userData.fullName}</h1>
                    <p className="text-gray-600">Age: {userData.age} years</p>
                  </div>
                </div>
                
                {/* Age Category Badge */}
                <div className="mt-4 md:mt-0 md:pb-2">
                  <Badge className={`px-3 py-1 text-sm font-medium ${getAgeGroupColor(userData.ageCategory)}`}>
                    <Shield className="w-4 h-4 mr-1" />
                    {userData.ageCategory} Verified
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Account Information */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Verification Details */}
        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Shield className="w-5 h-5 mr-2 text-green-600" />
              Verification Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Age Category</span>
              <Badge className={getAgeGroupColor(userData.ageCategory)}>
                {userData.ageCategory}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Verification ID</span>
              <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                {userData.tokenId.substring(0, 12)}...
              </code>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Status</span>
              <span className="text-sm text-green-600 font-medium">
                ✓ Verified
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Session Information */}
        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Clock className="w-5 h-5 mr-2 text-blue-600" />
              Session Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <span className="text-sm text-gray-600">Session Expires</span>
              <p className="text-sm font-medium text-gray-900 mt-1">
                {formatDate(userData.tokenExpiry)}
              </p>
            </div>
            
            <div>
              <span className="text-sm text-gray-600">Content Access</span>
              <p className="text-sm font-medium text-gray-900 mt-1">
                {userData.ageCategory} and below
              </p>
            </div>
            
            <div>
              <span className="text-sm text-gray-600">Account Type</span>
              <p className="text-sm font-medium text-gray-900 mt-1">
                Age-Verified User
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Preferences */}
      <Card className="border-0 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg">Content Preferences</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-gray-600">Show 13+ Content</span>
              <span className="text-sm text-green-600">✓ Enabled</span>
            </div>
            
            {userData.ageCategory !== '13+' && (
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-gray-600">Show 16+ Content</span>
                <span className="text-sm text-green-600">✓ Enabled</span>
              </div>
            )}
            
            {userData.ageCategory === '18+' && (
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-gray-600">Show 18+ Content</span>
                <span className="text-sm text-green-600">✓ Enabled</span>
              </div>
            )}
            
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-gray-600">Safe Browsing</span>
              <span className="text-sm text-green-600">✓ Active</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card className="border-0 shadow-md">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={onLogout}
              variant="outline"
              className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
            >
              Logout
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              disabled
            >
              Re-verify Identity
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}