import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, AlertCircle, Info, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const ageVerificationSchema = z.object({
  aadhaarToken: z.string().min(5, "Aadhaar verification token is required").max(50, "Invalid token format"),
  consentDataProcessing: z.boolean().refine(val => val === true, "You must consent to data processing"),
  consentAgeVerification: z.boolean().refine(val => val === true, "You must consent to age verification"),
  consentContentFiltering: z.boolean().refine(val => val === true, "You must consent to content filtering"),
});

type AgeVerificationForm = z.infer<typeof ageVerificationSchema>;

interface UserData {
  id: number;
  fullName: string;
  age: number;
  ageCategory: string;
  tokenId: string;
  tokenExpiry: string;
}

interface AgeVerificationFormProps {
  onSuccess: (data: UserData) => void;
}

export default function AgeVerificationForm({ onSuccess }: AgeVerificationFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<AgeVerificationForm>({
    resolver: zodResolver(ageVerificationSchema),
    defaultValues: {
      aadhaarToken: "",
      consentDataProcessing: false,
      consentAgeVerification: false,
      consentContentFiltering: false,
    },
  });

  const onSubmit = async (data: AgeVerificationForm) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await apiRequest('POST', '/api/verify-age', data);
      const result = await response.json();

      if (result.success) {
        onSuccess(result.user);
      } else {
        setError(result.error || "Verification failed");
      }
    } catch (err: any) {
      const errorMessage = err.message || "An error occurred during verification";
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="shadow-lg">
        <CardHeader>
          <div className="text-center">
            <div className="mx-auto w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">Aadhaar Age Verification</CardTitle>
            <p className="text-gray-600 mt-2">Secure age verification using your Aadhaar credentials</p>
          </div>
        </CardHeader>
        <CardContent>
          {/* Instructions */}
          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <div className="flex items-start">
              <Info className="w-5 h-5 text-blue-600 mr-2 mt-0.5" />
              <div>
                <h3 className="text-sm font-medium text-blue-900 mb-2">How to get your Aadhaar verification token:</h3>
                <ol className="text-sm text-blue-700 space-y-1">
                  <li>1. Open the official Aadhaar app on your mobile device</li>
                  <li>2. Navigate to "Age Verification" section</li>
                  <li>3. Generate a secure verification token</li>
                  <li>4. Copy and paste the token below</li>
                </ol>
              </div>
            </div>
          </div>

          {/* Demo tokens */}
          <div className="bg-yellow-50 rounded-lg p-4 mb-6">
            <div className="flex items-start">
              <CheckCircle className="w-5 h-5 text-yellow-600 mr-2 mt-0.5" />
              <div>
                <h3 className="text-sm font-medium text-yellow-900 mb-2">Demo Tokens (for testing):</h3>
                <div className="text-sm text-yellow-700 space-y-2">
                  <div className="space-y-1">
                    <div className="font-medium">Adults (18+):</div>
                    <div className="ml-2 space-y-1">
                      <div><code className="bg-yellow-100 px-2 py-1 rounded">ADULT001</code> - Rajesh Kumar (34 years)</div>
                      <div><code className="bg-yellow-100 px-2 py-1 rounded">ADULT002</code> - Priya Sharma (39 years)</div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="font-medium">Teens (16-17):</div>
                    <div className="ml-2 space-y-1">
                      <div><code className="bg-yellow-100 px-2 py-1 rounded">TEEN001</code> - Arjun Mehta (17 years)</div>
                      <div><code className="bg-yellow-100 px-2 py-1 rounded">TEEN002</code> - Kavya Nair (16 years)</div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="font-medium">Children (13-15):</div>
                    <div className="ml-2 space-y-1">
                      <div><code className="bg-yellow-100 px-2 py-1 rounded">CHILD001</code> - Ravi Agarwal (14 years)</div>
                      <div><code className="bg-yellow-100 px-2 py-1 rounded">CHILD002</code> - Neha Kapoor (13 years)</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <Label htmlFor="aadhaarToken" className="block text-sm font-medium text-gray-700 mb-2">
                Aadhaar Verification Token
              </Label>
              <Input
                id="aadhaarToken"
                type="text"
                placeholder="Enter your Aadhaar verification token"
                {...form.register("aadhaarToken")}
                className="w-full font-mono"
              />
              {form.formState.errors.aadhaarToken && (
                <p className="mt-1 text-sm text-red-600">
                  {form.formState.errors.aadhaarToken.message}
                </p>
              )}
            </div>

            {/* Consent checkboxes */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900">Required Consents</h3>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Controller
                    name="consentDataProcessing"
                    control={form.control}
                    render={({ field }) => (
                      <Checkbox
                        id="consentDataProcessing"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="mt-1"
                      />
                    )}
                  />
                  <Label htmlFor="consentDataProcessing" className="text-sm text-gray-700 leading-5">
                    I consent to the processing of my personal data for age verification purposes as per the Digital Personal Data Protection Act, 2023.
                  </Label>
                </div>
                {form.formState.errors.consentDataProcessing && (
                  <p className="ml-6 text-sm text-red-600">
                    {form.formState.errors.consentDataProcessing.message}
                  </p>
                )}

                <div className="flex items-start space-x-3">
                  <Controller
                    name="consentAgeVerification"
                    control={form.control}
                    render={({ field }) => (
                      <Checkbox
                        id="consentAgeVerification"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="mt-1"
                      />
                    )}
                  />
                  <Label htmlFor="consentAgeVerification" className="text-sm text-gray-700 leading-5">
                    I consent to age verification using my Aadhaar credentials and understand that my age category will be determined based on my date of birth.
                  </Label>
                </div>
                {form.formState.errors.consentAgeVerification && (
                  <p className="ml-6 text-sm text-red-600">
                    {form.formState.errors.consentAgeVerification.message}
                  </p>
                )}

                <div className="flex items-start space-x-3">
                  <Controller
                    name="consentContentFiltering"
                    control={form.control}
                    render={({ field }) => (
                      <Checkbox
                        id="consentContentFiltering"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="mt-1"
                      />
                    )}
                  />
                  <Label htmlFor="consentContentFiltering" className="text-sm text-gray-700 leading-5">
                    I consent to content filtering based on my verified age category and understand that content inappropriate for my age will be restricted.
                  </Label>
                </div>
                {form.formState.errors.consentContentFiltering && (
                  <p className="ml-6 text-sm text-red-600">
                    {form.formState.errors.consentContentFiltering.message}
                  </p>
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-900 mb-2">Content Categories</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center">
                  <span className="inline-block w-12 h-6 bg-green-500 text-white text-xs font-medium rounded px-2 py-1 mr-2">13+</span>
                  General content and discussions
                </div>
                <div className="flex items-center">
                  <span className="inline-block w-12 h-6 bg-yellow-500 text-white text-xs font-medium rounded px-2 py-1 mr-2">16+</span>
                  Mature themes and language
                </div>
                <div className="flex items-center">
                  <span className="inline-block w-12 h-6 bg-red-500 text-white text-xs font-medium rounded px-2 py-1 mr-2">18+</span>
                  Adult content and explicit material
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-primary hover:bg-blue-600"
              disabled={isLoading}
            >
              {isLoading ? "Verifying Aadhaar Token..." : "Verify Age with Aadhaar"}
            </Button>
          </form>

          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
