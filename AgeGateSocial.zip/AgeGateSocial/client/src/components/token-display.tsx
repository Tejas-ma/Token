import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";

interface UserData {
  id: number;
  fullName: string;
  age: number;
  ageCategory: string;
  tokenId: string;
  tokenExpiry: string;
}

interface TokenDisplayProps {
  userData: UserData;
}

export default function TokenDisplay({ userData }: TokenDisplayProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="max-w-2xl mx-auto mb-8">
      <Card className="shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Your Verification Token</h3>
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
              <CheckCircle className="w-4 h-4 mr-1" />
              Active
            </span>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-600">Verified Name</p>
                <p className="text-sm font-medium text-gray-900">{userData.fullName}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Token ID</p>
                <p className="font-mono text-sm text-gray-900">{userData.tokenId}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Age Category</p>
                <p className="text-sm font-medium text-gray-900">{userData.ageCategory}</p>
              </div>
            </div>
          </div>

          <div className="text-sm text-gray-600">
            <p className="mb-2">
              This token grants access to content rated{" "}
              <span className="font-medium text-gray-900">{userData.ageCategory}</span> and below.
            </p>
            <p>
              Token expires: <span className="font-medium">{formatDate(userData.tokenExpiry)}</span>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
