import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, MessageCircle, XCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Content {
  id: number;
  authorName: string;
  authorInitials: string;
  content: string;
  imageUrl?: string;
  ageRating: number;
  likes: number;
  comments: number;
  createdAt: string;
}

interface ContentFeedProps {
  token?: string;
  ageCategory?: string;
  onSessionExpired: () => void;
}

export default function ContentFeed({ token, ageCategory, onSessionExpired }: ContentFeedProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | '13' | '16' | '18'>('all');
  const [filteredContent, setFilteredContent] = useState<Content[]>([]);

  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/content/all'],
    queryFn: async () => {
      const response = await fetch('/api/content/all', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.status === 401) {
        onSessionExpired();
        throw new Error('Session expired');
      }

      if (!response.ok) {
        throw new Error('Failed to fetch content');
      }

      return response.json();
    },
    enabled: !!token,
  });

  useEffect(() => {
    if (data?.content) {
      const userMaxRating = getMaxRatingFromCategory(ageCategory || '13+');
      let filtered = data.content;

      // Filter by user's age category first
      filtered = filtered.filter((item: Content) => item.ageRating <= userMaxRating);

      // Then apply additional filter if not 'all'
      if (activeFilter !== 'all') {
        const filterRating = parseInt(activeFilter);
        filtered = filtered.filter((item: Content) => item.ageRating === filterRating);
      }

      setFilteredContent(filtered);
    }
  }, [data, activeFilter, ageCategory]);

  const getMaxRatingFromCategory = (category: string): number => {
    switch (category) {
      case '18+': return 18;
      case '16+': return 16;
      case '13+': return 13;
      default: return 0;
    }
  };

  const getTimeAgo = (dateString: string): string => {
    const now = new Date();
    const past = new Date(dateString);
    const diffInHours = Math.floor((now.getTime() - past.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  const getRatingBadgeColor = (rating: number): string => {
    switch (rating) {
      case 13: return 'bg-green-100 text-green-800';
      case 16: return 'bg-yellow-100 text-yellow-800';
      case 18: return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const hasRestrictedContent = data?.content?.some((item: Content) => 
    item.ageRating > getMaxRatingFromCategory(ageCategory || '13+')
  );

  if (isLoading) {
    return (
      <div>
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Content Feed</h2>
          <div className="flex space-x-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-10 w-24" />
            ))}
          </div>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center mb-3">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div className="ml-3 flex-1">
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4 mb-3" />
                <Skeleton className="h-48 w-full rounded-lg" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <XCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load content. Please try refreshing the page.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with welcome message and filters */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Welcome to Social Feed</h2>
            <p className="text-gray-600 mt-1">Discover content curated for your age category</p>
          </div>
          <div className="mt-4 md:mt-0">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              {ageCategory} Access
            </span>
          </div>
        </div>
        
        {/* Filter buttons */}
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={() => setActiveFilter('all')}
            variant={activeFilter === 'all' ? 'default' : 'outline'}
            size="sm"
            className={activeFilter === 'all' ? 'bg-primary text-white' : ''}
          >
            All Content
          </Button>
          <Button
            onClick={() => setActiveFilter('13')}
            variant={activeFilter === '13' ? 'default' : 'outline'}
            size="sm"
            className={activeFilter === '13' ? 'bg-green-500 text-white hover:bg-green-600' : 'border-green-500 text-green-600 hover:bg-green-50'}
          >
            13+ Only
          </Button>
          <Button
            onClick={() => setActiveFilter('16')}
            variant={activeFilter === '16' ? 'default' : 'outline'}
            size="sm"
            className={activeFilter === '16' ? 'bg-yellow-500 text-white hover:bg-yellow-600' : 'border-yellow-500 text-yellow-600 hover:bg-yellow-50'}
          >
            16+ Only
          </Button>
          <Button
            onClick={() => setActiveFilter('18')}
            variant={activeFilter === '18' ? 'default' : 'outline'}
            size="sm"
            className={activeFilter === '18' ? 'bg-red-500 text-white hover:bg-red-600' : 'border-red-500 text-red-600 hover:bg-red-50'}
          >
            18+ Only
          </Button>
        </div>
      </div>

      {/* Content grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredContent.map((item) => (
          <Card key={item.id} className="shadow-md hover:shadow-lg transition-shadow duration-200 overflow-hidden border-0">
            <CardContent className="p-0">
              {/* Header */}
              <div className="p-4 pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-white">{item.authorInitials}</span>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">{item.authorName}</p>
                      <p className="text-xs text-gray-500">{getTimeAgo(item.createdAt)}</p>
                    </div>
                  </div>
                  <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${getRatingBadgeColor(item.ageRating)}`}>
                    {item.ageRating}+
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="px-4 pb-3">
                <p className="text-gray-800 text-sm leading-relaxed">{item.content}</p>
              </div>
              
              {/* Image */}
              {item.imageUrl && (
                <div className="px-4 pb-3">
                  <img 
                    src={item.imageUrl} 
                    alt="Content image" 
                    className="w-full h-48 object-cover rounded-lg"
                  />
                </div>
              )}
              
              {/* Actions */}
              <div className="px-4 py-3 bg-gray-50 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button className="flex items-center text-gray-600 hover:text-red-500 transition-colors">
                    <Heart className="w-4 h-4 mr-1" />
                    <span className="text-sm">{item.likes}</span>
                  </button>
                  <button className="flex items-center text-gray-600 hover:text-blue-500 transition-colors">
                    <MessageCircle className="w-4 h-4 mr-1" />
                    <span className="text-sm">{item.comments}</span>
                  </button>
                </div>
                <div className="text-xs text-gray-500">
                  {getTimeAgo(item.createdAt)}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Content restriction notice */}
      {hasRestrictedContent && activeFilter === 'all' && (
        <Alert className="border-amber-200 bg-amber-50">
          <XCircle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-amber-700">
            <strong>Content Filtered:</strong> Some content is hidden based on your age verification. 
            Content rated above your {ageCategory} category is not displayed.
          </AlertDescription>
        </Alert>
      )}

      {/* Empty state */}
      {filteredContent.length === 0 && !isLoading && (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <XCircle className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No content found</h3>
          <p className="text-gray-600">Try adjusting your filter or check back later for new content.</p>
        </div>
      )}
    </div>
  );
}
