import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, Heart, MessageCircle, User } from "lucide-react";

interface Content {
  id: number;
  authorName: string;
  authorInitials: string;
  content: string;
  imageUrl?: string;
  ageRating: number;
  likes: number;
  comments: number;
  createdAt: string;
}

interface SearchTabProps {
  token?: string;
  ageCategory?: string;
  onSessionExpired: () => void;
}

export default function SearchTab({ token, ageCategory, onSessionExpired }: SearchTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState<string>("all");

  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/content/all', token],
    enabled: !!token,
    retry: (failureCount, error) => {
      if (error.message.includes('401')) {
        onSessionExpired();
        return false;
      }
      return failureCount < 3;
    },
  });

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const getRatingBadgeColor = (rating: number) => {
    switch (rating) {
      case 13: return 'bg-green-100 text-green-800';
      case 16: return 'bg-yellow-100 text-yellow-800';
      case 18: return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getMaxRatingFromCategory = (category: string) => {
    switch (category) {
      case '18+': return 18;
      case '16+': return 16;
      case '13+': return 13;
      default: return 0;
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center space-x-4">
          <div className="flex-1 h-10 bg-gray-200 rounded-lg animate-pulse"></div>
          <div className="w-20 h-10 bg-gray-200 rounded-lg animate-pulse"></div>
        </div>
        <div className="grid gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <p className="text-red-700">Unable to load content. Please try again.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const userMaxRating = getMaxRatingFromCategory(ageCategory || '13+');
  const allContent = data?.content || [];
  
  // Filter content based on age rating
  let filteredContent = allContent.filter((item: Content) => item.ageRating <= userMaxRating);
  
  // Apply search filter
  if (searchQuery.trim()) {
    filteredContent = filteredContent.filter((item: Content) =>
      item.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.authorName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }
  
  // Apply rating filter
  if (selectedFilter !== "all") {
    const filterRating = parseInt(selectedFilter);
    filteredContent = filteredContent.filter((item: Content) => item.ageRating === filterRating);
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Search Header */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search content, authors, or topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              Filter
            </Button>
          </div>
          
          {/* Quick Filters */}
          <div className="flex flex-wrap gap-2 mt-4">
            <Button
              size="sm"
              variant={selectedFilter === "all" ? "default" : "outline"}
              onClick={() => setSelectedFilter("all")}
            >
              All Content
            </Button>
            <Button
              size="sm"
              variant={selectedFilter === "13" ? "default" : "outline"}
              onClick={() => setSelectedFilter("13")}
              className={selectedFilter === "13" ? "bg-green-500 hover:bg-green-600" : "border-green-500 text-green-600 hover:bg-green-50"}
            >
              13+ Only
            </Button>
            {userMaxRating >= 16 && (
              <Button
                size="sm"
                variant={selectedFilter === "16" ? "default" : "outline"}
                onClick={() => setSelectedFilter("16")}
                className={selectedFilter === "16" ? "bg-yellow-500 hover:bg-yellow-600" : "border-yellow-500 text-yellow-600 hover:bg-yellow-50"}
              >
                16+ Only
              </Button>
            )}
            {userMaxRating >= 18 && (
              <Button
                size="sm"
                variant={selectedFilter === "18" ? "default" : "outline"}
                onClick={() => setSelectedFilter("18")}
                className={selectedFilter === "18" ? "bg-red-500 hover:bg-red-600" : "border-red-500 text-red-600 hover:bg-red-50"}
              >
                18+ Only
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      <div className="space-y-4">
        {filteredContent.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-12 text-center">
              <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {searchQuery ? "No results found" : "Start searching"}
              </h3>
              <p className="text-gray-600">
                {searchQuery 
                  ? `No content found matching "${searchQuery}"`
                  : "Enter a search term to find content, authors, or topics"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Results Count */}
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Found {filteredContent.length} result{filteredContent.length !== 1 ? 's' : ''}
                {searchQuery && ` for "${searchQuery}"`}
              </p>
            </div>

            {/* Content List */}
            <div className="space-y-4">
              {filteredContent.map((item) => (
                <Card key={item.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      {/* Avatar */}
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-medium text-white">
                          {item.authorInitials}
                        </span>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-medium text-gray-900">
                              {item.authorName}
                            </span>
                            <span className="text-sm text-gray-500">
                              {getTimeAgo(item.createdAt)}
                            </span>
                          </div>
                          <Badge className={getRatingBadgeColor(item.ageRating)}>
                            {item.ageRating}+
                          </Badge>
                        </div>

                        <p className="text-gray-800 text-sm mb-3 leading-relaxed">
                          {item.content}
                        </p>

                        {item.imageUrl && (
                          <img 
                            src={item.imageUrl} 
                            alt="Content image" 
                            className="w-full max-w-md h-48 object-cover rounded-lg mb-3"
                          />
                        )}

                        <div className="flex items-center space-x-4 text-gray-500">
                          <button className="flex items-center hover:text-red-500 transition-colors">
                            <Heart className="w-4 h-4 mr-1" />
                            <span className="text-sm">{item.likes}</span>
                          </button>
                          <button className="flex items-center hover:text-blue-500 transition-colors">
                            <MessageCircle className="w-4 h-4 mr-1" />
                            <span className="text-sm">{item.comments}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}