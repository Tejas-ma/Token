import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import AgeVerificationForm from "@/components/age-verification-form";
import ContentFeed from "@/components/content-feed";
import ProfileTab from "@/components/profile-tab";
import SearchTab from "@/components/search-tab";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Home as HomeIcon, Search, User, Heart, MessageCircle, PlusCircle } from "lucide-react";

interface UserData {
  id: number;
  fullName: string;
  age: number;
  ageCategory: string;
  tokenId: string;
  tokenExpiry: string;
}

export default function Home() {
  const [isVerified, setIsVerified] = useState(false);
  const [userData, setUserData] = useState<UserData | null>(null);
  const { toast } = useToast();

  // Check for existing token on mount
  useEffect(() => {
    const storedToken = localStorage.getItem('ageVerificationToken');
    const storedUserData = localStorage.getItem('userData');
    
    if (storedToken && storedUserData) {
      const parsedUserData = JSON.parse(storedUserData);
      
      // Check if token is expired
      if (new Date() < new Date(parsedUserData.tokenExpiry)) {
        setUserData(parsedUserData);
        setIsVerified(true);
      } else {
        // Clean up expired token
        localStorage.removeItem('ageVerificationToken');
        localStorage.removeItem('userData');
      }
    }
  }, []);

  const handleVerificationSuccess = (data: UserData) => {
    setUserData(data);
    setIsVerified(true);
    
    // Store token and user data
    localStorage.setItem('ageVerificationToken', data.tokenId);
    localStorage.setItem('userData', JSON.stringify(data));
    
    toast({
      title: "Age Verified Successfully",
      description: `Welcome ${data.fullName}! You now have access to ${data.ageCategory} content and below.`,
    });
  };

  const handleLogout = () => {
    setIsVerified(false);
    setUserData(null);
    
    // Clear stored data
    localStorage.removeItem('ageVerificationToken');
    localStorage.removeItem('userData');
    
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully.",
    });
  };

  const handleSessionExpired = () => {
    handleLogout();
    toast({
      title: "Session Expired",
      description: "Your verification token has expired. Please verify your age again.",
      variant: "destructive",
    });
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      {!isVerified ? (
        <>
          {/* Header */}
          <header className="bg-white shadow-sm border-b border-gray-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center h-16">
                <div className="flex items-center">
                  <h1 className="text-2xl font-bold text-gray-900">AgeGuard</h1>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <AgeVerificationForm onSuccess={handleVerificationSuccess} />
          </main>
        </>
      ) : (
        <div className="flex flex-col h-screen">
          {/* Header */}
          <header className="bg-white shadow-sm border-b border-gray-200 flex-shrink-0">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center h-16">
                <div className="flex items-center">
                  <h1 className="text-2xl font-bold text-gray-900">AgeGuard</h1>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-600">
                    Welcome, <span className="font-medium">{userData?.fullName}</span>
                  </span>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content with Tabs */}
          <main className="flex-1 overflow-hidden">
            <Tabs defaultValue="browse" className="h-full flex flex-col">
              {/* Tab Navigation */}
              <div className="bg-white border-b border-gray-200 px-4 sm:px-6 lg:px-8">
                <div className="max-w-7xl mx-auto">
                  <TabsList className="grid w-full grid-cols-3 bg-gray-100 p-1 rounded-lg">
                    <TabsTrigger value="browse" className="flex items-center space-x-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                      <HomeIcon className="w-4 h-4" />
                      <span className="hidden sm:inline">Browse</span>
                    </TabsTrigger>
                    <TabsTrigger value="search" className="flex items-center space-x-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                      <Search className="w-4 h-4" />
                      <span className="hidden sm:inline">Search</span>
                    </TabsTrigger>
                    <TabsTrigger value="profile" className="flex items-center space-x-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                      <User className="w-4 h-4" />
                      <span className="hidden sm:inline">Profile</span>
                    </TabsTrigger>
                  </TabsList>
                </div>
              </div>

              {/* Tab Content */}
              <div className="flex-1 overflow-auto">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                  <TabsContent value="browse" className="mt-0 h-full">
                    <ContentFeed 
                      token={userData?.tokenId} 
                      ageCategory={userData?.ageCategory}
                      onSessionExpired={handleSessionExpired}
                    />
                  </TabsContent>
                  
                  <TabsContent value="search" className="mt-0 h-full">
                    <SearchTab
                      token={userData?.tokenId}
                      ageCategory={userData?.ageCategory}
                      onSessionExpired={handleSessionExpired}
                    />
                  </TabsContent>
                  
                  <TabsContent value="profile" className="mt-0 h-full">
                    <ProfileTab
                      userData={userData!}
                      onLogout={handleLogout}
                    />
                  </TabsContent>
                </div>
              </div>
            </Tabs>
          </main>
        </div>
      )}
    </div>
  );
}
