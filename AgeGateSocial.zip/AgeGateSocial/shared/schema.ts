import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  aadhaarToken: text("aadhaar_token").notNull(),
  fullName: text("full_name").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  age: integer("age").notNull(),
  ageCategory: text("age_category").notNull(),
  tokenId: text("token_id").notNull().unique(),
  tokenExpiry: timestamp("token_expiry").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const content = pgTable("content", {
  id: serial("id").primaryKey(),
  authorName: text("author_name").notNull(),
  authorInitials: text("author_initials").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  ageRating: integer("age_rating").notNull(),
  likes: integer("likes").notNull().default(0),
  comments: integer("comments").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  aadhaarToken: true,
  fullName: true,
  dateOfBirth: true,
});

export const insertContentSchema = createInsertSchema(content).omit({
  id: true,
  createdAt: true,
});

export const ageVerificationSchema = z.object({
  aadhaarToken: z.string().min(5, "Aadhaar verification token is required").max(50, "Invalid token format"),
  consentDataProcessing: z.boolean().refine(val => val === true, "You must consent to data processing"),
  consentAgeVerification: z.boolean().refine(val => val === true, "You must consent to age verification"),
  consentContentFiltering: z.boolean().refine(val => val === true, "You must consent to content filtering"),
});

export const tokenValidationSchema = z.object({
  token: z.string().min(1, "Token is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertContent = z.infer<typeof insertContentSchema>;
export type Content = typeof content.$inferSelect;
export type AgeVerificationRequest = z.infer<typeof ageVerificationSchema>;
export type TokenValidationRequest = z.infer<typeof tokenValidationSchema>;
