import { db } from "./db";
import { content } from "@shared/schema";

const seedContent = [
  {
    authorName: "John Doe",
    authorInitials: "JD",
    content: "Just discovered this amazing new coffee shop downtown! The atmosphere is perfect for studying or catching up with friends. ☕️",
    imageUrl: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 13,
    likes: 24,
    comments: 8,
  },
  {
    authorName: "Alice Smith",
    authorInitials: "AS",
    content: "Movie night discussion: Just watched the latest thriller. The psychological tension was incredible, though some scenes were quite intense. What did everyone think about the ending? 🎬",
    imageUrl: "https://images.unsplash.com/photo-1489599217565-916b3e4b2e7c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 16,
    likes: 42,
    comments: 17,
  },
  {
    authorName: "Bob Johnson",
    authorInitials: "BJ",
    content: "Exploring the local nightlife scene tonight. The energy downtown is incredible, and I've met some fascinating people. The music venues here are world-class! 🌃",
    imageUrl: "https://images.unsplash.com/photo-1572544049465-c2aeb33b9c52?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 18,
    likes: 156,
    comments: 89,
  },
  {
    authorName: "Emma Wilson",
    authorInitials: "EW",
    content: "Saturday morning at the farmers market! Fresh produce, local crafts, and the best breakfast burritos in town. Supporting local businesses feels great! 🥕",
    imageUrl: "https://images.unsplash.com/photo-1488459716781-31db52582fe9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 13,
    likes: 78,
    comments: 23,
  },
  {
    authorName: "Michael Brown",
    authorInitials: "MB",
    content: "Gaming tournament tonight! The competition is fierce but the atmosphere is electric. Nothing beats the thrill of competitive esports with friends. 🎮",
    imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 13,
    likes: 134,
    comments: 67,
  },
  {
    authorName: "Sarah Davis",
    authorInitials: "SD",
    content: "Art exhibition opening was incredible! The contemporary pieces really challenge conventional thinking. Some provocative themes that spark important conversations. 🎨",
    imageUrl: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 16,
    likes: 89,
    comments: 45,
  },
  {
    authorName: "Sarah Lee",
    authorInitials: "SL",
    content: "Discussing the complex economic implications of recent policy changes. These decisions affect real people's livelihoods and require thoughtful analysis. 📊",
    imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    ageRating: 18,
    likes: 203,
    comments: 127,
  },
];

export async function seedDatabase() {
  console.log("Seeding database...");
  
  try {
    // Check if content already exists
    const existingContent = await db.select().from(content);
    
    if (existingContent.length === 0) {
      // Insert seed content
      await db.insert(content).values(seedContent);
      console.log("Database seeded successfully!");
    } else {
      console.log("Database already has content, skipping seed.");
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Run seed if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase().then(() => process.exit(0));
}