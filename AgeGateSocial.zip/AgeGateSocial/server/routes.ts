import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ageVerificationSchema, tokenValidationSchema } from "@shared/schema";
import { z } from "zod";

function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
}

// Mock Aadhaar verification service
function verifyAadhaarToken(aadhaarToken: string): { valid: boolean; userData?: { fullName: string; dateOfBirth: string; } } {
  // Simulate Aadhaar verification with more age groups
  const mockAadhaarData: Record<string, { fullName: string; dateOfBirth: string; }> = {
    // Adults (18+)
    "ADULT001": { fullName: "Rajesh Kumar", dateOfBirth: "1990-05-15" },
    "ADULT002": { fullName: "Priya Sharma", dateOfBirth: "1985-08-22" },
    "ADULT003": { fullName: "Amit Patel", dateOfBirth: "1988-12-10" },
    "ADULT004": { fullName: "Sneha Reddy", dateOfBirth: "1992-03-18" },
    "ADULT005": { fullName: "Vikram Singh", dateOfBirth: "1995-11-25" },
    
    // Teens (16-17)
    "TEEN001": { fullName: "Arjun Mehta", dateOfBirth: "2007-06-12" },
    "TEEN002": { fullName: "Kavya Nair", dateOfBirth: "2008-09-08" },
    "TEEN003": { fullName: "Rohit Joshi", dateOfBirth: "2007-01-22" },
    "TEEN004": { fullName: "Ananya Das", dateOfBirth: "2008-04-15" },
    "TEEN005": { fullName: "Karan Gupta", dateOfBirth: "2007-12-03" },
    
    // Children (13-15)
    "CHILD001": { fullName: "Ravi Agarwal", dateOfBirth: "2010-07-08" },
    "CHILD002": { fullName: "Neha Kapoor", dateOfBirth: "2011-02-14" },
    "CHILD003": { fullName: "Aarav Sharma", dateOfBirth: "2009-10-20" },
    "CHILD004": { fullName: "Ishita Verma", dateOfBirth: "2010-05-30" },
    "CHILD005": { fullName: "Dev Patel", dateOfBirth: "2011-08-17" },
    
    // Legacy tokens (keeping for backward compatibility)
    "AADH1234567890": { fullName: "Rajesh Kumar", dateOfBirth: "1990-05-15" },
    "AADH0987654321": { fullName: "Priya Sharma", dateOfBirth: "2000-08-22" },
    "AADH1122334455": { fullName: "Amit Patel", dateOfBirth: "1985-12-10" },
    "AADH5566778899": { fullName: "Sneha Reddy", dateOfBirth: "2005-03-18" },
    "AADH9988776655": { fullName: "Vikram Singh", dateOfBirth: "1995-11-25" },
    "AADH1357924680": { fullName: "Kavya Nair", dateOfBirth: "2010-07-08" },
  };
  
  if (mockAadhaarData[aadhaarToken]) {
    return { valid: true, userData: mockAadhaarData[aadhaarToken] };
  }
  
  return { valid: false };
}

function determineAgeCategory(age: number): string {
  if (age >= 18) return '18+';
  if (age >= 16) return '16+';
  if (age >= 13) return '13+';
  return 'under13';
}

function generateToken(): string {
  return 'AGV-2024-' + Math.random().toString(36).substr(2, 8).toUpperCase();
}

function getMaxRatingFromCategory(category: string): number {
  switch (category) {
    case '18+': return 18;
    case '16+': return 16;
    case '13+': return 13;
    default: return 0;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Age verification endpoint
  app.post("/api/verify-age", async (req, res) => {
    try {
      console.log("Request body:", req.body);
      const parseResult = ageVerificationSchema.safeParse(req.body);
      if (!parseResult.success) {
        console.log("Validation errors:", parseResult.error.errors);
        return res.status(400).json({
          error: parseResult.error.errors[0]?.message || "Validation failed"
        });
      }
      const { aadhaarToken, consentDataProcessing, consentAgeVerification, consentContentFiltering } = parseResult.data;
      
      // Verify Aadhaar token
      const aadhaarVerification = verifyAadhaarToken(aadhaarToken);
      
      if (!aadhaarVerification.valid) {
        return res.status(400).json({
          error: "Invalid Aadhaar verification token. Please generate a new token from the Aadhaar app."
        });
      }
      
      const { fullName, dateOfBirth } = aadhaarVerification.userData!;
      const age = calculateAge(dateOfBirth);
      
      if (age < 13) {
        return res.status(400).json({
          error: "You must be at least 13 years old to use this platform"
        });
      }
      
      const ageCategory = determineAgeCategory(age);
      const tokenId = generateToken();
      const tokenExpiry = new Date();
      tokenExpiry.setDate(tokenExpiry.getDate() + 30); // 30 days from now
      
      const user = await storage.createUser({
        aadhaarToken,
        fullName,
        dateOfBirth,
        age,
        ageCategory,
        tokenId,
        tokenExpiry,
        createdAt: new Date(),
      });
      
      res.json({
        success: true,
        user: {
          id: user.id,
          fullName: user.fullName,
          age: user.age,
          ageCategory: user.ageCategory,
          tokenId: user.tokenId,
          tokenExpiry: user.tokenExpiry,
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          error: error.errors[0].message
        });
      }
      
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  // Token validation endpoint
  app.post("/api/validate-token", async (req, res) => {
    try {
      const { token } = tokenValidationSchema.parse(req.body);
      
      const user = await storage.getUserByToken(token);
      
      if (!user) {
        return res.status(401).json({
          error: "Invalid token"
        });
      }
      
      // Check if token is expired
      if (new Date() > user.tokenExpiry) {
        return res.status(401).json({
          error: "Token expired"
        });
      }
      
      res.json({
        valid: true,
        user: {
          id: user.id,
          age: user.age,
          ageCategory: user.ageCategory,
          tokenId: user.tokenId,
          tokenExpiry: user.tokenExpiry,
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          error: error.errors[0].message
        });
      }
      
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  // Get content endpoint
  app.get("/api/content", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      
      if (!token) {
        return res.status(401).json({
          error: "No token provided"
        });
      }
      
      const user = await storage.getUserByToken(token);
      
      if (!user) {
        return res.status(401).json({
          error: "Invalid token"
        });
      }
      
      if (new Date() > user.tokenExpiry) {
        return res.status(401).json({
          error: "Token expired"
        });
      }
      
      const maxRating = getMaxRatingFromCategory(user.ageCategory);
      const content = await storage.getContentByAgeRating(maxRating);
      
      res.json({
        content,
        userCategory: user.ageCategory,
        maxRating
      });
    } catch (error) {
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  // Get all content (for filtering)
  app.get("/api/content/all", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      
      if (!token) {
        return res.status(401).json({
          error: "No token provided"
        });
      }
      
      const user = await storage.getUserByToken(token);
      
      if (!user) {
        return res.status(401).json({
          error: "Invalid token"
        });
      }
      
      if (new Date() > user.tokenExpiry) {
        return res.status(401).json({
          error: "Token expired"
        });
      }
      
      const allContent = await storage.getAllContent();
      const maxRating = getMaxRatingFromCategory(user.ageCategory);
      
      res.json({
        content: allContent,
        userCategory: user.ageCategory,
        maxRating
      });
    } catch (error) {
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
