import { users, content, type User, type InsertUser, type Content, type InsertContent } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  createUser(user: Omit<User, 'id'>): Promise<User>;
  getUserByToken(tokenId: string): Promise<User | undefined>;
  
  // Content operations
  getAllContent(): Promise<Content[]>;
  getContentByAgeRating(maxRating: number): Promise<Content[]>;
  createContent(content: InsertContent): Promise<Content>;
}

export class DatabaseStorage implements IStorage {
  async createUser(userData: Omit<User, 'id'>): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async getUserByToken(tokenId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.tokenId, tokenId));
    return user || undefined;
  }

  async getAllContent(): Promise<Content[]> {
    const allContent = await db.select().from(content);
    return allContent.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getContentByAgeRating(maxRating: number): Promise<Content[]> {
    const allContent = await this.getAllContent();
    return allContent.filter(item => item.ageRating <= maxRating);
  }

  async createContent(contentData: InsertContent): Promise<Content> {
    const [newContent] = await db
      .insert(content)
      .values(contentData)
      .returning();
    return newContent;
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private content: Map<number, Content>;
  private userIdCounter: number;
  private contentIdCounter: number;

  constructor() {
    this.users = new Map();
    this.content = new Map();
    this.userIdCounter = 1;
    this.contentIdCounter = 1;
    
    // Initialize with mock content
    this.initializeMockContent();
  }

  private initializeMockContent() {
    const mockContent: Omit<Content, 'id'>[] = [
      {
        authorName: "John Doe",
        authorInitials: "JD",
        content: "Just discovered this amazing new coffee shop downtown! The atmosphere is perfect for studying or catching up with friends. ☕️",
        imageUrl: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
        ageRating: 13,
        likes: 24,
        comments: 8,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        authorName: "Alice Smith",
        authorInitials: "AS",
        content: "Movie night discussion: Just watched the latest thriller. The psychological tension was incredible, though some scenes were quite intense. What did everyone think about the ending? 🎬",
        imageUrl: "https://pixabay.com/get/ge9b7a849b8de2b3ce1e6f308a89a2b439ed6785ecd9b644d897316d6ca3902bca68d53056ca4a6435aaf8dab5f559f5caa4fa130a9ed638011fb0cc4763baaff_1280.jpg",
        ageRating: 16,
        likes: 67,
        comments: 23,
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        authorName: "Mike Johnson",
        authorInitials: "MJ",
        content: "Sharing my thoughts on the current political climate and its impact on social justice movements. These are complex issues that require mature discussion and critical thinking. 🗳️",
        imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
        ageRating: 18,
        likes: 142,
        comments: 89,
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      },
      {
        authorName: "Emily Brown",
        authorInitials: "EB",
        content: "Beautiful sunset from my evening walk today! Nature never fails to amaze me. Hope everyone had a wonderful day! 🌅",
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
        ageRating: 13,
        likes: 156,
        comments: 34,
        createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
      },
      {
        authorName: "Ryan Garcia",
        authorInitials: "RG",
        content: "Game night got pretty intense last night! We were playing some competitive strategy games until 3 AM. The trash talk was real! 🎮",
        imageUrl: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
        ageRating: 16,
        likes: 89,
        comments: 45,
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
      },
      {
        authorName: "Sarah Lee",
        authorInitials: "SL",
        content: "Discussing the complex economic implications of recent policy changes. These decisions affect real people's livelihoods and require thoughtful analysis. 📊",
        imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
        ageRating: 18,
        likes: 203,
        comments: 127,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      },
    ];

    mockContent.forEach(content => {
      this.createContent(content);
    });
  }

  async createUser(userData: Omit<User, 'id'>): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...userData, id };
    this.users.set(id, user);
    return user;
  }

  async getUserByToken(tokenId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.tokenId === tokenId);
  }

  async getAllContent(): Promise<Content[]> {
    return Array.from(this.content.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getContentByAgeRating(maxRating: number): Promise<Content[]> {
    return Array.from(this.content.values())
      .filter(content => content.ageRating <= maxRating)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createContent(contentData: InsertContent): Promise<Content> {
    const id = this.contentIdCounter++;
    const content: Content = {
      ...contentData,
      id,
      imageUrl: contentData.imageUrl || null,
      likes: contentData.likes || 0,
      comments: contentData.comments || 0,
      createdAt: new Date(),
    };
    this.content.set(id, content);
    return content;
  }
}

export const storage = new DatabaseStorage();
