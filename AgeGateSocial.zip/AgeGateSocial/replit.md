# Age Verification Content Platform

## Overview

This is a full-stack web application built with React/TypeScript frontend and Express.js backend that implements Aadhaar-based age verification for social media content access. The system verifies user ages through Aadhaar tokens, generates secure platform tokens, and filters content based on age ratings (13+, 16+, 18+). The application uses a modern tech stack with Drizzle ORM for database operations, shadcn/ui components, and TanStack Query for state management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for persistent data storage
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Validation**: Zod schemas for runtime type checking
- **Session Management**: Token-based authentication with expiry
- **Development**: Hot reloading with Vite integration
- **Data Layer**: DatabaseStorage class implementing IStorage interface for database operations

### Key Design Decisions
1. **Age Verification Strategy**: Aadhaar-based verification system using secure tokens generated from the official Aadhaar app, with fallback to mock data for development
2. **User Consent Management**: Comprehensive consent system for data processing, age verification, and content filtering compliance
3. **Content Filtering**: Age rating system (13+, 16+, 18+) with server-side filtering based on user's verified age category
4. **Data Storage**: PostgreSQL database with Drizzle ORM for persistent user data and content storage
5. **Component Architecture**: Modular React components with clear separation of concerns

## Key Components

### Authentication & Verification
- **Aadhaar Age Verification Form**: Collects Aadhaar verification tokens and validates user consent
- **Mock Aadhaar Service**: Simulates Aadhaar verification with predefined test tokens for development (ADULT001-005, TEEN001-005, CHILD001-005)
- **Token System**: Generates secure platform tokens with expiry dates for authenticated sessions
- **Consent Management**: Comprehensive consent collection for data processing, age verification, and content filtering
- **Session Management**: Automatic token validation and cleanup of expired sessions

### Social Media Interface
- **Tabbed Navigation**: Three-tab interface (Browse, Search, Profile) similar to popular social media apps
- **Browse Tab**: Main content feed with age-appropriate filtering
- **Search Tab**: Full-text search functionality with content filtering
- **Profile Tab**: User profile display with verification status and account details
- **Content Feed**: Displays age-appropriate content with filtering capabilities
- **Content Filtering**: Real-time filtering based on age ratings (All, 13+, 16+, 18+)
- **Content Display**: Rich content cards with images, user interactions, and timestamps

### UI Components
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Accessible Components**: Radix UI primitives ensure accessibility compliance
- **Loading States**: Skeleton loading and proper error handling
- **Toast Notifications**: User feedback for actions and errors
- **Sticky Header**: Fixed navigation header for better user experience
- **Gradient Avatars**: Visual user representation with gradient backgrounds

## Data Flow

1. **User Registration**: User submits Aadhaar verification token → Aadhaar validation → user data retrieval → age calculation → age category determination → platform token generation → user data stored in PostgreSQL database
2. **Content Access**: Platform token validation → user lookup in database → age category retrieval → content filtering → display filtered content
3. **Session Management**: Token stored in localStorage → automatic validation on app load → database lookup for user verification → cleanup on expiry
4. **Consent Management**: User consent collection → validation → storage alongside user data in database
5. **Content Management**: Content stored in database → age-based filtering → real-time retrieval based on user permissions

### Database Schema
```typescript
// Users table
users: {
  id: serial primary key
  aadhaarToken: text
  fullName: text
  dateOfBirth: text
  age: integer
  ageCategory: text (13+, 16+, 18+, under13)
  tokenId: text unique
  tokenExpiry: timestamp
  createdAt: timestamp
}

// Content table
content: {
  id: serial primary key
  authorName: text
  authorInitials: text
  content: text
  imageUrl: text (optional)
  ageRating: integer (13, 16, 18)
  likes: integer
  comments: integer
  createdAt: timestamp
}
```

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **UI Libraries**: Radix UI components, Lucide React icons
- **State Management**: TanStack Query for server state
- **Validation**: Zod for schema validation
- **Utilities**: date-fns for date manipulation, clsx for conditional classes

### Backend Dependencies
- **Database**: Drizzle ORM with PostgreSQL dialect, Neon Database serverless
- **Validation**: Zod for request validation
- **Development**: tsx for TypeScript execution, esbuild for production builds

### Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **ESLint/Prettier**: Code formatting and linting
- **Vite Plugins**: Runtime error overlay, cartographer for development

## Deployment Strategy

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code with external dependencies
- **Database**: Drizzle migrations handle schema changes

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment detection for development/production features
- **Replit Integration**: Special handling for Replit environment with development banners

### Development Workflow
1. Local development uses in-memory storage for rapid iteration
2. Database migrations can be applied with `npm run db:push`
3. Hot reloading enabled for both frontend and backend changes
4. Production deployment compiles to single bundle with static assets

### Security Considerations
- Age verification tokens have built-in expiry mechanisms
- Content filtering enforced at both client and server levels
- Input validation using Zod schemas prevents malformed data
- CORS and security headers configured for production deployment